# AddApi

All URIs are relative to *http://felec.computec.com/api/v1/calculator*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add**](AddApi.md#add) | **GET** /add/parametros | Realiza la suma de varios numeros separados por /


<a name="add"></a>
# **add**
> String add(parametros)

Realiza la suma de varios numeros separados por /

Realiza la suma de varios numeros separados por /

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AddApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

AddApi apiInstance = new AddApi();
String parametros = "parametros_example"; // String | valores a sumar separados por /
try {
    String result = apiInstance.add(parametros);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AddApi#add");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **parametros** | **String**| valores a sumar separados por / |

### Return type

**String**

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/html

