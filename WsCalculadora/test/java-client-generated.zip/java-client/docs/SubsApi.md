# SubsApi

All URIs are relative to *http://felec.computec.com/api/v1/calculator*

Method | HTTP request | Description
------------- | ------------- | -------------
[**subs**](SubsApi.md#subs) | **GET** /subs/parametros | Resta los valores de parametros y devuelve un html con la respuesta


<a name="subs"></a>
# **subs**
> Map&lt;String, Integer&gt; subs(parametros)

Resta los valores de parametros y devuelve un html con la respuesta

Resta los valores que vienen y retorna un html con la respuesta

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SubsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

SubsApi apiInstance = new SubsApi();
String parametros = "parametros_example"; // String | valores a restar separados por /
try {
    Map<String, Integer> result = apiInstance.subs(parametros);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SubsApi#subs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **parametros** | **String**| valores a restar separados por / |

### Return type

**Map&lt;String, Integer&gt;**

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/html

