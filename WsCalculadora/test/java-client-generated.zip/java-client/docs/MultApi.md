# MultApi

All URIs are relative to *http://felec.computec.com/api/v1/calculator*

Method | HTTP request | Description
------------- | ------------- | -------------
[**mult**](MultApi.md#mult) | **GET** /mult/parametros | Realiza la multiplicación de varios numeros separados por /


<a name="mult"></a>
# **mult**
> String mult(parametros)

Realiza la multiplicación de varios numeros separados por /

Realiza la suma de varios numeros separados por /

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MultApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

MultApi apiInstance = new MultApi();
String parametros = "parametros_example"; // String | valores a multiplicar separados por /
try {
    String result = apiInstance.mult(parametros);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MultApi#mult");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **parametros** | **String**| valores a multiplicar separados por / |

### Return type

**String**

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/html

