# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.AddApi;

import java.io.File;
import java.util.*;

public class AddApiExample {

    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        
        // Configure API key authorization: api_key
        ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
        api_key.setApiKey("YOUR API KEY");
        // Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
        //api_key.setApiKeyPrefix("Token");

        AddApi apiInstance = new AddApi();
        String parametros = "parametros_example"; // String | valores a sumar separados por /
        try {
            String result = apiInstance.add(parametros);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling AddApi#add");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *http://felec.computec.com/api/v1/calculator*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AddApi* | [**add**](docs/AddApi.md#add) | **GET** /add/parametros | Realiza la suma de varios numeros separados por /
*DivApi* | [**div**](docs/DivApi.md#div) | **GET** /div/parametros | Realiza la división de varios numeros separados por /
*MultApi* | [**mult**](docs/MultApi.md#mult) | **GET** /mult/parametros | Realiza la multiplicación de varios numeros separados por /
*SubsApi* | [**subs**](docs/SubsApi.md#subs) | **GET** /subs/parametros | Resta los valores de parametros y devuelve un html con la respuesta


## Documentation for Models



## Documentation for Authorization

Authentication schemes defined for the API:
### api_key

- **Type**: API key
- **API key parameter name**: api_key
- **Location**: HTTP header

### petstore_auth

- **Type**: OAuth
- **Flow**: implicit
- **Authorization URL**: http://petstore.swagger.io/oauth/dialog
- **Scopes**: 
  - write:pets: modify pets in your account
  - read:pets: read your pets


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author

johanvelandia@gmail.com

